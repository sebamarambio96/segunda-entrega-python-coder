import json


def guardar_bd(bd):
    try:
        archivo = open("./data.json", "w+")
        archivo.write(json.dumps(bd))
        archivo.close()
    except:
        print("Algo a salido mal")
    else:
        print("Archivo creado o actualizado")


def leer_bd(bd):
    archivo = open("./data.json", "r")
    contenido = archivo.read()
    archivo.close()
    return json.loads(contenido)


def login(bd):
    leer_bd(bd)
    usuario = input("Ingrese su nombre de usuario: ")
    password = input("Ingrese su contraseña: ")
    while True:
        try:
            existe = []
            for user in bd:
                if user["usuario"] == usuario:
                    existe.append(user)
                    if user["pass"] != password:
                        raise Exception("Contraseña incorrecta")
            if len(existe) == 0:
                raise Exception("Nombre de usuario no existe")
        except Exception as x:
            print(str(x))
            break
        else:
            print("Se inicio sesión exitosamente")
            break


def mostrar_bd(bd):
    info = ""
    for user in bd:
        nombre = user["usuario"]
        password = user["pass"]
        info += f"Nombre de usuario: {nombre} Contraseña: {password} \n"
    print(info)


def registro(bd):
    while True:
        try:
            nuevo_usuario = {}
            nuevo_usuario["usuario"] = input("Ingresa un nombre usuario: ")
            for user in bd:
                if nuevo_usuario["usuario"] == user["usuario"]:
                    raise Exception(
                        "Lo siento ese nombre de usuario ya existe")
            nuevo_usuario["pass"] = input("Ingresa una contraseña: ")
            bd.append(nuevo_usuario)
        except Exception as x:
            print(str(x))
        else:
            guardar_bd(bd)
            print("Usuario registrado exitosamente")
            break
