from setuptools import setup

setup(
    name = "segunda-entrega",
    packages = ['primera_entrega','segunda_entrega'],
    version = 1,
    description = 'Paquete para segunda entrega',
    author= 'Sebastián Marambio Sandoval'
)